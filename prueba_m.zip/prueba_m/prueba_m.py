
import os
import webbrowser

# Elementos de entrada en el formulario
input_value = {
    'Passwd' : 'MY PASSWORD', 
    'Email' : 'MY EMAIL', 
    'continue': 'https://mail.google.com'
    }
action='https://www.google.com/accounts/ServiceLoginAuth?service=mail'
method='post'

#Configurar la función de envío de formularios JavaScript. 
#Estoy usando la función 'formato' en una cadena, y no me gusta el {and} de la función js
#Así que lo saqué para insertarlo más tarde
js_submit = '$(document).ready(function() {$("#form").submit(); });'

# Configurar elementos de contenido de archivo
input_field = '<input type="hidden" name="{0}" value="{1}" />'

base_file_contents = """
<script src='http://www.google.com/jsapi'></script>
<script>
    google.load('jquery', '1.3.2');
</script>

<script>
    {0}
</script>

<form id='form' action='{1}' method='{2}' />
    {3}
</form>
"""

# Construir campos de entrada
input_fields = ""

for key, value in input_value.items():
    input_fields += input_field.format(key, value)
    
# Abrir página web    
with open('temp_file.html', "w") as file:
    file.write(base_file_contents.format(js_submit,action, method, input_fields))
    file.close()
    webbrowser.open(os.path.abspath(file.name))
    os.remove(os.path.abspath(file.name))
